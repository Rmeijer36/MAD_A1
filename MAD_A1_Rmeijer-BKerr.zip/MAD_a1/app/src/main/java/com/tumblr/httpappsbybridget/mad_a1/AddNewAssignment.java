/*
* File Name    : AddNewAssignment.java
* Project Name : Mobile Application Development - Assignment 1 : Assignment Planner
* Author(s)    : Richard Meijer, Bridget Kerr
* Submit Date  : 2/7/2016
* Description  : Assignment Planner - tracks assignment details.
*                This page allows a user to enter new information for an assignment.
* */

package com.tumblr.httpappsbybridget.mad_a1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class AddNewAssignment extends AppCompatActivity {
    Button saveButton = null;
    Button cancelButton = null;
    EditText etTitle = null;
    EditText etDueDate = null;
    Spinner prioritySpinner = null;
    EditText etDetails = null;
    EditText etTasks = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_assignment);

        // Initialize variables
        etTitle = (EditText) findViewById(R.id.editTextTitle);
        etDueDate = (EditText) findViewById(R.id.editTextDueDate);
        prioritySpinner = (Spinner) findViewById(R.id.spinnerPriority);
        etDetails = (EditText) findViewById(R.id.editTextDetails);
        etTasks = (EditText) findViewById(R.id.editTextTasks);

        // Initialize button and onclicklistener, call saveAssignment method
        saveButton = (Button)findViewById(R.id.buttonSave);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveAssignment();
            }
        });
    }

    // Sets text values in shared preferences
    private void saveAssignment() {
        SharedPreferences preferences = getApplicationContext().getSharedPreferences("assignment", MainActivity.MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = preferences.edit();

        editor.putString("title", etTitle.getText().toString());
        editor.putString("datetime", etDueDate.getText().toString());
        editor.putString("priority", prioritySpinner.getSelectedItem().toString());
        editor.putString("details", etDetails.getText().toString());
        editor.putString("tasks", etTasks.getText().toString());
        editor.commit();
        this.finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add_new_assignment, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
